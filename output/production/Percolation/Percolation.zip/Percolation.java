import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private boolean[][] openedSites;
    private int vTopSite, vBottomSite, numOpenSites;
    private WeightedQuickUnionUF wufGrid;
    private WeightedQuickUnionUF wufFull;
    private int gridSide;

    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException();
        }
        this.gridSide = n;
        openedSites = new boolean[gridSide][gridSide];
        wufGrid = new WeightedQuickUnionUF(gridSide * gridSide + 2);
        wufFull = new WeightedQuickUnionUF(gridSide * gridSide + 1);
        vTopSite = gridSide * gridSide;
        vBottomSite = gridSide * gridSide + 1;
        numOpenSites = 0;
    }

    public void open(int row, int col) {
        if (checkIndex(row, col)) {
            if (!isOpen(row, col)) {
                openedSites[row - 1][col - 1] = true;
                numOpenSites++;
            }
            if (row == 1) {
                wufGrid.union(col - 1, vTopSite);
                wufFull.union(col - 1, vTopSite);
            }
            if (row == gridSide) wufGrid.union((row - 1) * gridSide + col - 1, vBottomSite);
            if (row > 1 && isOpen(row - 1, col)) {
                wufGrid.union((row - 1) * gridSide + col - 1, (row - 2) * gridSide + col - 1);
                wufFull.union((row - 1) * gridSide + col - 1, (row - 2) * gridSide + col - 1);
            }
            if (row < gridSide && isOpen(row + 1, col)) {
                wufGrid.union((row - 1) * gridSide + col - 1, row * gridSide + col - 1);
                wufFull.union((row - 1) * gridSide + col - 1, row * gridSide + col - 1);
            }
            if (col > 1 && isOpen(row, col - 1)) {
                wufGrid.union((row - 1) * gridSide + col - 1, (row - 1) * gridSide + col - 2);
                wufFull.union((row - 1) * gridSide + col - 1, (row - 1) * gridSide + col - 2);
            }
            if (col < gridSide && isOpen(row, col + 1)) {
                wufGrid.union((row - 1) * gridSide + col - 1, (row - 1) * gridSide + col);
                wufFull.union((row - 1) * gridSide + col - 1, (row - 1) * gridSide + col);
            }
        } else {
            throw new java.lang.IllegalArgumentException();
        }
    }

    public boolean isOpen(int row, int col) {
        if (checkIndex(row, col)) {
            return openedSites[row - 1][col - 1];
        }
        throw new java.lang.IllegalArgumentException();
    }

    public boolean isFull(int row, int col) {
        if (checkIndex(row, col)) {
            return wufFull.connected((row - 1) * gridSide + col - 1, vTopSite);
        }
        throw new java.lang.IllegalArgumentException();
    }

    public int numberOfOpenSites() {
        return numOpenSites;
    }

    public boolean percolates() {
        return wufGrid.connected(vTopSite, vBottomSite);
    }

    private boolean checkIndex(int row, int col) {
        if (row < 1 || row > gridSide || col < 1 || col > gridSide) return false;
        return true;
    }
}
